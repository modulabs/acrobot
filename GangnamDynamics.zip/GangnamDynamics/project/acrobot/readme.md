# Acrobot

Acrobot implementation

[1] http://ieeecss.org/CSM/library/1995/feb1995/02-swingupctrlprob.pdf







